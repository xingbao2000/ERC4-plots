# matplotlib nbagg
import matplotlib.pyplot as plt
import matplotlib
import matplotlib.font_manager as font_manager
import pandas as pd
import numpy as np
import sys

fig_size = plt.rcParams["figure.figsize"]
fig_size[0] = 9
fig_size[1] = 6
#plt.rcParams["figure.figsize"] = fig_size
plt.figure(figsize=(9,6))


def median(lst):
    n = len(lst)
    s = sorted(lst)
    return (sum(s[n//2-1:n//2+1])/2.0, s[n//2])[n % 2] if n else None

hour = np.empty(10)
means = np.empty(10)
v = np.empty((10, 84))

# f = open ('3d_pmin.dat.12h','r').readlines()
f = open ('3d_vmax.dat.dx','r').readlines()
# print ('f=',f)
cnt = 0
#for line in f[0:]:
for line in f[1:]:
    # print ("line=",line)
    line=line.strip('\n')
    fields = line.split(' ')
    #print ("fields=",fields)
    print ("fields1,fields8=",fields[1],fields[8])
    for i in range (1, 85):
      v[cnt,i-1]=fields[i]
    means[cnt] = np.mean(v[cnt,:])
    cnt += 1

print ("V00=",v[0,:])
print ("V01=",v[1,:])
print ("V09=",v[9,:])

mmin = min(v[1,:])
mmax = max(v[1,:])
#mean = mean(v01)
mmedian = median(v[1,:])
#std = std(v01)
#print( min,max,mean,std )
print( mmin,mmax,mmedian )

#labels = ['L27_D6K', 'L27_D4K', 'L27_D2K', 'L27_1.33', 'L27_0.67', 'L54_D6K', 'L54_D4K', 'L54_D2K', 'L54_1.33', 'L54_0.67']
labels = ['D6_L27', 'D4_L27', 'D2_L27', 'D1.33_L27', 'D.67_L27', 'D6_L54', 'D4_L54', 'D2_L54', 'D1.33_L54', 'D.67_L54']

plt.boxplot((v[0,:], v[1,:], v[2,:], v[3,:], v[4,:], v[5,:], v[6,:], v[7,:], v[8,:], v[9,:]), \
        labels=labels, sym='+', vert=True, whis=1.5)
#        labels=labels, showfliers=False)
plt.scatter([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], means)

plt.xlabel('Experiment',fontsize=12)
# plt.ylabel('Pmin (hPa)',fontsize=12)
plt.ylabel('Vmax (m/s)',fontsize=12)

# plt.show()
plt.savefig('box-vmax.png')
plt.savefig('box-vmax.eps')

'''
filepath = '3d_pmin.dat.12h'
with open(filepath) as fp:
   line = fp.readline()
   cnt = 1
   while line:
       print("Line {}: {}".format(cnt, line.strip()))
       line = fp.readline()
       cnt += 1
df = pd.DataFrame(np.random.rand(10, 5), columns=['A', 'B', 'C', 'D', 'E'])
df.plot.box(grid='True')

plt.show()

# construct some data like what you have:
x = np.random.randn(100, 8)
mins = x.min(0)
maxes = x.max(0)
means = x.mean(0)
std = x.std(0)

# create stacked errorbars:
plt.errorbar(np.arange(8), means, std, fmt='ok', lw=3)
plt.errorbar(np.arange(8), means, [means - mins, maxes - means],
             fmt='.k', ecolor='gray', lw=1)
plt.xlim(-1, 8)

plt.show()

#plt.xlabel('xlabel', fontsize=18)
#plt.ylabel('ylabel', fontsize=16)
#fig.savefig('tracks21.png')
#fig.savefig('tracks21.eps')

'''
